<?php


$pdo = new PDO('mysql:host=localhost;dbname=serenatto', 'root', 'senhaDoDatabase1227');